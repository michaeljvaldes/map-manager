var UnminedRegions = [
];
